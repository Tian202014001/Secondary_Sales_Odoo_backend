# -*- coding: utf-8 -*-

from odoo import fields, models


class ResMobileRole(models.Model):
    _name = "res.mobile.role"
    _description = "Mobile User Role"
    _order = "sequence, name"

    name = fields.Char(required=True, translate=True)
    code = fields.Char(required=True, index=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    description = fields.Text()
    user_ids = fields.One2many("res.mobile.user", "role_id", string="Mobile Users")

    _sql_constraints = [
        ("code_uniq", "unique(code)", "The mobile role code must be unique."),
    ]
