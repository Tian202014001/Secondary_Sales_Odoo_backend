# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.api_custom.utils.sale_order_utils import (
    get_sale_order_domain, get_pagination, serialize_sale_orders
)

class SaleOrderController(http.Controller):

    @http.route('/api/custom/sale_orders', type='json', auth='public', methods=['POST'])
    def get_sale_orders(self, **kw):
        """Fetch sale orders and return their key parameters with filters and pagination"""
        try:
            domain = get_sale_order_domain(kw)
            limit, offset = get_pagination(kw)
            
            orders = request.env['sale.order'].sudo().search(domain, limit=limit, offset=offset)
            
            return {
                "success": True,
                "sale_orders": serialize_sale_orders(orders)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
