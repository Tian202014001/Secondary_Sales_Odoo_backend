# -*- coding: utf-8 -*-
from odoo import http
from odoo.addons.api_custom.utils.mobile_auth_utils import (
    get_current_mobile_auth_context,
    get_mobile_integration_model,
    require_mobile_auth,
)
from odoo.addons.api_custom.utils.respartner_utils import (
    get_partner_domain, get_pagination, serialize_partners
)

class ResPartnerController(http.Controller):

    @http.route('/api/custom/partners', type='json', auth='public', methods=['POST'])
    @require_mobile_auth()
    def get_partners(self, **kw):
        """Fetch partners and return their key parameters with filters and pagination"""
        try:
            auth_context = get_current_mobile_auth_context()
            domain = get_partner_domain(kw)
            limit, offset = get_pagination(kw)
            Partner = get_mobile_integration_model('res.partner')
            partners = Partner.search(domain, limit=limit, offset=offset)
            
            return {
                "success": True,
                "mobile_user_id": auth_context["mobile_user"].id,
                "partners": serialize_partners(partners)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
