# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.api_custom.utils.stock_location_utils import (
    get_location_domain, get_pagination, serialize_locations
)

class StockLocationController(http.Controller):

    @http.route('/api/custom/locations', type='json', auth='public', methods=['POST'])
    def get_locations(self, **kw):
        """Fetch stock locations and return their key parameters with filters and pagination"""
        try:
            domain = get_location_domain(kw)
            limit, offset = get_pagination(kw)
            
            locations = request.env['stock.location'].sudo().search(domain, limit=limit, offset=offset)
            
            return {
                "success": True,
                "locations": serialize_locations(locations)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
