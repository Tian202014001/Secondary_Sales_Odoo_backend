# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.api_custom.utils.hr_employee_utils import (
    get_employee_domain, get_pagination, serialize_employees
)

class HrEmployeeController(http.Controller):

    @http.route('/api/custom/employees', type='json', auth='public', methods=['POST'])
    def get_employees(self, **kw):
        """Fetch employees and return their key parameters with filters and pagination"""
        try:
            domain = get_employee_domain(kw)
            limit, offset = get_pagination(kw)
            
            employees = request.env['hr.employee'].sudo().search(domain, limit=limit, offset=offset)
            
            return {
                "success": True,
                "employees": serialize_employees(employees)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
