# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.api_custom.utils.stock_warehouse_utils import (
    get_warehouse_domain, get_pagination, serialize_warehouses
)

class StockWarehouseController(http.Controller):

    @http.route('/api/custom/warehouses', type='json', auth='public', methods=['POST'])
    def get_warehouses(self, **kw):
        """Fetch stock warehouses and return their key parameters with filters and pagination"""
        try:
            domain = get_warehouse_domain(kw)
            limit, offset = get_pagination(kw)
            
            warehouses = request.env['stock.warehouse'].sudo().search(domain, limit=limit, offset=offset)
            
            return {
                "success": True,
                "warehouses": serialize_warehouses(warehouses)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
