# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.api_custom.utils.product_product_utils import (
    get_product_domain, get_pagination, serialize_products
)

class ProductProductController(http.Controller):

    @http.route('/api/custom/products', type='json', auth='public', methods=['POST'])
    def get_products(self, **kw):
        """Fetch product variants and return their key parameters with filters and pagination"""
        try:
            domain = get_product_domain(kw)
            limit, offset = get_pagination(kw)
            
            products = request.env['product.product'].sudo().search(domain, limit=limit, offset=offset)
            
            return {
                "success": True,
                "products": serialize_products(products)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
