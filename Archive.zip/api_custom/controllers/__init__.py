# -*- coding: utf-8 -*-
from . import res_partner
from . import product_product
from . import stock_warehouse
from . import stock_location
from . import hr_employee
from . import sale_order


