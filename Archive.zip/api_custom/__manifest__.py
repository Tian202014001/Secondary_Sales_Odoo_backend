# -*- coding: utf-8 -*-
{
    'name': "Custom Partner API",
    'summary': "API for accessing res.partner data from Odoo",
    'description': """
        Exposes JSON-RPC API endpoints to perform CRUD operations on res.partner.
    """,
    'author': "Antigravity",
    'category': 'Tools',
    'version': '1.0',
    'depends': ['base', 'product', 'stock', 'hr', 'sale', 'meta_api_user'],
    'data': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
