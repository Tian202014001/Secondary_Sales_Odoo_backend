# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)

def get_pagination(kw):
    """Calculate limit and offset from kw parameters"""
    try:
        page = int(kw.get('page', 1))
        page_size = int(kw.get('page_size', 20))
    except (ValueError, TypeError):
        page = 1
        page_size = 20

    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 20
        
    offset = (page - 1) * page_size
    return page_size, offset

def get_partner_domain(kw):
    """Build Odoo domain from kw parameters for res.partner"""
    domain = []
    
    # Text-based filters (ilike)
    if kw.get('name'):
        domain.append(('name', 'ilike', str(kw.get('name'))))
    if kw.get('city'):
        domain.append(('city', 'ilike', str(kw.get('city'))))
    if kw.get('email'):
        domain.append(('email', 'ilike', str(kw.get('email'))))
    if kw.get('phone'):
        domain.append(('phone', 'ilike', str(kw.get('phone'))))
        
    # ID/Relational filters
    if kw.get('id'):
        try:
            domain.append(('id', '=', int(kw.get('id'))))
        except (ValueError, TypeError):
            pass
            
    return domain

def serialize_partners(partners):
    """Convert partner records to serialized dictionary format"""
    partner_list = []
    for partner in partners:
        partner_list.append({
            "id": partner.id,
            "name": partner.name,
            "email": partner.email or None,
            "phone": partner.phone or None,
            "mobile": partner.mobile or None,
            "street": partner.street or None,
            "city": partner.city or None,
            "zip": partner.zip or None,
        })
    return partner_list
