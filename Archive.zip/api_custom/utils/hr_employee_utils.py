# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)

def get_pagination(kw):
    """Calculate limit and offset from kw parameters"""
    try:
        page = int(kw.get('page', 1))
        page_size = int(kw.get('page_size', 20))
    except (ValueError, TypeError):
        page = 1
        page_size = 20

    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 20
        
    offset = (page - 1) * page_size
    return page_size, offset

def get_employee_domain(kw):
    """Build Odoo domain from kw parameters for hr.employee"""
    domain = []
    
    # Text-based filters
    if kw.get('name'):
        domain.append(('name', 'ilike', str(kw.get('name'))))
    if kw.get('work_email'):
        domain.append(('work_email', 'ilike', str(kw.get('work_email'))))
    if kw.get('work_phone'):
        domain.append(('work_phone', 'ilike', str(kw.get('work_phone'))))
    if kw.get('mobile_phone'):
        domain.append(('mobile_phone', 'ilike', str(kw.get('mobile_phone'))))
        
    # ID/Relational filters
    if kw.get('id'):
        try:
            domain.append(('id', '=', int(kw.get('id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('department_id'):
        try:
            domain.append(('department_id', '=', int(kw.get('department_id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('job_id'):
        try:
            domain.append(('job_id', '=', int(kw.get('job_id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('parent_id'):
        try:
            domain.append(('parent_id', '=', int(kw.get('parent_id'))))
        except (ValueError, TypeError):
            pass
            
    # Boolean filters
    if 'active' in kw:
        active_val = kw.get('active')
        if isinstance(active_val, str):
            active_val = active_val.lower() == 'true'
        domain.append(('active', '=', bool(active_val)))
        
    return domain

def serialize_employees(employees):
    """Convert employee records to serialized dictionary format"""
    employee_list = []
    for emp in employees:
        employee_list.append({
            "id": emp.id,
            "name": emp.name,
            "work_email": emp.work_email or None,
            "work_phone": emp.work_phone or None,
            "mobile_phone": emp.mobile_phone or None,
            "active": emp.active,
            "department": {
                "id": emp.department_id.id,
                "name": emp.department_id.name
            } if emp.department_id else None,
            "job": {
                "id": emp.job_id.id,
                "name": emp.job_id.name
            } if emp.job_id else None,
            "parent/manager": {
                "id": emp.parent_id.id,
                "name": emp.parent_id.name
            } if emp.parent_id else None,
        })
    return employee_list
