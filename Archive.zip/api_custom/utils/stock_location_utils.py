# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)

def get_pagination(kw):
    """Calculate limit and offset from kw parameters"""
    try:
        page = int(kw.get('page', 1))
        page_size = int(kw.get('page_size', 20))
    except (ValueError, TypeError):
        page = 1
        page_size = 20

    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 20
        
    offset = (page - 1) * page_size
    return page_size, offset

def get_location_domain(kw):
    """Build Odoo domain from kw parameters for stock.location"""
    domain = []
    
    # Text-based filters
    if kw.get('name'):
        domain.append(('name', 'ilike', str(kw.get('name'))))
    if kw.get('complete_name'):
        domain.append(('complete_name', 'ilike', str(kw.get('complete_name'))))
    if kw.get('usage'):
        domain.append(('usage', '=', str(kw.get('usage'))))
    if kw.get('barcode'):
        domain.append(('barcode', 'ilike', str(kw.get('barcode'))))
        
    # ID/Relational filters
    if kw.get('id'):
        try:
            domain.append(('id', '=', int(kw.get('id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('location_id'):
        try:
            domain.append(('location_id', '=', int(kw.get('location_id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('company_id'):
        try:
            domain.append(('company_id', '=', int(kw.get('company_id'))))
        except (ValueError, TypeError):
            pass
            
    # Boolean filters
    if 'active' in kw:
        active_val = kw.get('active')
        if isinstance(active_val, str):
            active_val = active_val.lower() == 'true'
        domain.append(('active', '=', bool(active_val)))
        
    return domain

def serialize_locations(locations):
    """Convert location records to serialized dictionary format"""
    location_list = []
    for loc in locations:
        location_list.append({
            "id": loc.id,
            "name": loc.name,
            "complete_name": loc.complete_name or loc.name,
            "usage": loc.usage or None,
            "active": loc.active,
            "parent_location": {
                "id": loc.location_id.id,
                "name": loc.location_id.name
            } if loc.location_id else None,
            "company": {
                "id": loc.company_id.id,
                "name": loc.company_id.name
            } if loc.company_id else None,
            "barcode": loc.barcode or None,
        })
    return location_list
