# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)

def get_pagination(kw):
    """Calculate limit and offset from kw parameters"""
    try:
        page = int(kw.get('page', 1))
        page_size = int(kw.get('page_size', 20))
    except (ValueError, TypeError):
        page = 1
        page_size = 20

    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 20
        
    offset = (page - 1) * page_size
    return page_size, offset

def get_product_domain(kw):
    """Build Odoo domain from kw parameters for product.product"""
    domain = []
    
    # Text-based filters
    if kw.get('name'):
        domain.append(('name', 'ilike', str(kw.get('name'))))
    if kw.get('default_code'):
        domain.append(('default_code', 'ilike', str(kw.get('default_code'))))
    if kw.get('barcode'):
        domain.append(('barcode', 'ilike', str(kw.get('barcode'))))
    if kw.get('type'):
        domain.append(('type', '=', str(kw.get('type'))))
        
    # ID/Relational filters
    if kw.get('id'):
        try:
            domain.append(('id', '=', int(kw.get('id'))))
        except (ValueError, TypeError):
            pass
            
    # Boolean filters
    if 'active' in kw:
        active_val = kw.get('active')
        if isinstance(active_val, str):
            active_val = active_val.lower() == 'true'
        domain.append(('active', '=', bool(active_val)))
        
    return domain

def serialize_products(products):
    """Convert product records to serialized dictionary format"""
    product_list = []
    for product in products:
        product_list.append({
            "id": product.id,
            "name": product.name,
            "default_code": product.default_code or None,
            "barcode": product.barcode or None,
            "list_price": product.list_price or 0.0,
            "standard_price": product.standard_price or 0.0,
            "type": product.type or None,
            "active": product.active,
        })
    return product_list
