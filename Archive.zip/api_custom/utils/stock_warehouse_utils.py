# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)

def get_pagination(kw):
    """Calculate limit and offset from kw parameters"""
    try:
        page = int(kw.get('page', 1))
        page_size = int(kw.get('page_size', 20))
    except (ValueError, TypeError):
        page = 1
        page_size = 20

    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 20
        
    offset = (page - 1) * page_size
    return page_size, offset

def get_warehouse_domain(kw):
    """Build Odoo domain from kw parameters for stock.warehouse"""
    domain = []
    
    # Text-based filters
    if kw.get('name'):
        domain.append(('name', 'ilike', str(kw.get('name'))))
    if kw.get('code'):
        domain.append(('code', 'ilike', str(kw.get('code'))))
        
    # ID/Relational filters
    if kw.get('id'):
        try:
            domain.append(('id', '=', int(kw.get('id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('company_id'):
        try:
            domain.append(('company_id', '=', int(kw.get('company_id'))))
        except (ValueError, TypeError):
            pass
            
    # Boolean filters
    if 'active' in kw:
        active_val = kw.get('active')
        if isinstance(active_val, str):
            active_val = active_val.lower() == 'true'
        domain.append(('active', '=', bool(active_val)))
        
    return domain

def serialize_warehouses(warehouses):
    """Convert warehouse records to serialized dictionary format"""
    warehouse_list = []
    for wh in warehouses:
        warehouse_list.append({
            "id": wh.id,
            "name": wh.name,
            "code": wh.code,
            "active": wh.active,
            "company": {
                "id": wh.company_id.id,
                "name": wh.company_id.name
            } if wh.company_id else None,
            "partner": {
                "id": wh.partner_id.id,
                "name": wh.partner_id.name
            } if wh.partner_id else None,
        })
    return warehouse_list
