# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)

def get_pagination(kw):
    """Calculate limit and offset from kw parameters"""
    try:
        page = int(kw.get('page', 1))
        page_size = int(kw.get('page_size', 20))
    except (ValueError, TypeError):
        page = 1
        page_size = 20

    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 20
        
    offset = (page - 1) * page_size
    return page_size, offset

def get_sale_order_domain(kw):
    """Build Odoo domain from kw parameters for sale.order"""
    domain = []
    
    # Text-based / state filters
    if kw.get('name'):
        domain.append(('name', 'ilike', str(kw.get('name'))))
    if kw.get('state'):
        domain.append(('state', '=', str(kw.get('state'))))
        
    # ID/Relational filters
    if kw.get('id'):
        try:
            domain.append(('id', '=', int(kw.get('id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('customer_id'):
        try:
            domain.append(('partner_id', '=', int(kw.get('customer_id'))))
        except (ValueError, TypeError):
            pass
    if kw.get('salesperson_id'):
        try:
            domain.append(('user_id', '=', int(kw.get('salesperson_id'))))
        except (ValueError, TypeError):
            pass
            
    return domain

def serialize_sale_orders(orders):
    """Convert sale order records to serialized dictionary format"""
    order_list = []
    for order in orders:
        lines = []
        for line in order.order_line:
            lines.append({
                "id": line.id,
                "product": {
                    "id": line.product_id.id,
                    "name": line.product_id.name
                } if line.product_id else None,
                "product_uom_qty": line.product_uom_qty,
                "price_unit": line.price_unit,
                "price_subtotal": line.price_subtotal,
            })
            
        order_list.append({
            "id": order.id,
            "name": order.name,
            "state": order.state,
            "date_order": str(order.date_order) if order.date_order else None,
            "amount_untaxed": order.amount_untaxed,
            "amount_tax": order.amount_tax,
            "amount_total": order.amount_total,
            "customer": {
                "id": order.partner_id.id,
                "name": order.partner_id.name
            } if order.partner_id else None,
            "salesperson": {
                "id": order.user_id.id,
                "name": order.user_id.name
            } if order.user_id else None,
            "lines": lines,
        })
    return order_list
