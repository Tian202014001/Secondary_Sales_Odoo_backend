# -*- coding: utf-8 -*-

from functools import wraps

from odoo.exceptions import AccessDenied
from odoo.http import request


def get_bearer_token():
    """Extract the raw Bearer token from the Authorization header."""
    authorization = request.httprequest.headers.get("Authorization", "")
    parts = authorization.strip().split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer" or not parts[1].strip():
        raise AccessDenied("Missing bearer token.")
    return parts[1].strip()


def validate_mobile_access_token(check_session=True):
    """Validate mobile JWT access token and return auth context."""
    token = get_bearer_token()
    mobile_user, payload, session = request.env["mobile.auth.session"].sudo().validate_access_token(
        token,
        check_session=check_session,
    )
    return {
        "mobile_user": mobile_user,
        "payload": payload,
        "session": session,
    }


def get_current_mobile_auth_context():
    """Return auth context set by require_mobile_auth()."""
    return getattr(request, "mobile_auth_context", None)


def get_mobile_integration_model(model_name):
    """Return a model recordset running as the configured Mobile API integration user."""
    return request.env["mobile.auth.session"].sudo().get_integration_model(model_name)


def require_mobile_auth(check_session=True):
    """Decorator for type='json' API endpoints that require a mobile access token."""
    def decorator(method):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                request.mobile_auth_context = validate_mobile_access_token(
                    check_session=check_session
                )
            except AccessDenied:
                return {
                    "success": False,
                    "error": "unauthorized",
                }
            return method(*args, **kwargs)
        return wrapper
    return decorator
